from shiny import App, render, ui
import mimetypes
from math import ceil
from typing import List
from shiny import App, render, ui

from shiny import *
from shiny.types import FileInfo
import pandas as pd

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from starlette.applications import Starlette
from starlette.routing import Mount
from starlette.staticfiles import StaticFiles

#first app
app_ui1 = ui.page_fluid(

    #ui for feedback
    ui.input_text("feedback", "feedback", placeholder="Please give feedback"),
    ui.output_text("txt"),

    #ui for csv
    ui.layout_sidebar(
        ui.panel_sidebar(
            ui.input_file("file1", "Choose CSV File", accept=[".csv"], multiple=False),
            ui.input_checkbox("header", "Header", True),
        ),
        ui.output_table("contents"),
    ),
)


def server(input, output, session):

    @output
    @render.table
    def contents():
        if input.file1() is None:
            return "Please upload a csv file"
        f: list[FileInfo] = input.file1()
        iris = pd.read_csv(f[0]["datapath"], header=0 if input.header() else None)
        return iris

    @output
    @render.text
    def txt():
        return f'feedback: "{input.feedback()}"'


app_static = App(app_ui1, server, debug=True)

#2nd app
app_ui2 = ui.page_fluid(

    #output for feedback
    ui.output_text("txt"),

    #output for csv
    ui.output_table("contents")
    )
def sever(input,output,session):

    # for csv
    @output
    @render.table
    def contents():
        return iris

    @output
    @render.text
    def txt():
        return f'feedback: "{input.feedback()}"' 
app_shiny = App(app_ui2,sever,debug = True)


#combine of two apps
routes = [
    Mount('/static', app=app_static),
    Mount('/shiny', app=app_shiny)
]

app = Starlette(routes = routes)
